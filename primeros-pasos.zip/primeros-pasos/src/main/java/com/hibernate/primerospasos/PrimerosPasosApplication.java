package com.hibernate.primerospasos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerosPasosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerosPasosApplication.class, args);
	}

}
