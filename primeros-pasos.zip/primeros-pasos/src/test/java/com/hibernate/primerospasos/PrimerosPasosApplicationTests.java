package com.hibernate.primerospasos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerosPasosApplicationTests {

	@Test
	void contextLoads() {
	}

}
